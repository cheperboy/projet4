import json, os.path
from appconfig import *

DATA_JSON_FILE = 'data.json'
DATA_JSON_FILE_ZONES = 'zones.json'
DATA_JSON_FILE_SYSTEM = 'system.json'

def init_data_old():
    if not os.path.isfile(DATA_JSON_FILE):
        data = {
           'system_state' : 'OFF',
           'zone_1' : 'UNDEFINED',
           'zone_2' : 'UNDEFINED',
           'zone_3' : 'UNDEFINED',
           'zone_4' : 'UNDEFINED',
        }
        save_data(data)
        with open(DATA_JSON_FILE, 'r') as f:
            jsondata = json.load(f)
            jsondata['zone1'] = 'DETECTED'
        with open(DATA_JSON_FILE, 'w') as f:
            json.dump(jsondata, f)


def get_data(var):
    with open(DATA_JSON_FILE, 'r') as f:
        data = json.load(f)
        return data[var]

def set_data(var, val):
    with open(DATA_JSON_FILE, 'r') as f:
        data = json.load(f)
        data[var] = val
    with open(DATA_JSON_FILE, 'w') as f:
        json.dump(data, f)

def save_data(data):
    with open(DATA_JSON_FILE, 'w') as f:
        json.dump(data, f)
        
#NEW VERSION
def init_data():
    global ZONES
    global SYSTEM_IN
    if not os.path.isfile(DATA_JSON_FILE_ZONES):
        with open(DATA_JSON_FILE_ZONES, 'w') as f:
            json.dump(ZONES, f)
    if not os.path.isfile(DATA_JSON_FILE_SYSTEM):
        with open(DATA_JSON_FILE_SYSTEM, 'w') as f:
            json.dump(SYSTEM_IN, f)

def get_zone_state_from_file():
    with open(DATA_JSON_FILE_ZONES, 'r') as f:
         data = json.load(f)
    return data

def get_system_state_from_file():
    with open(DATA_JSON_FILE_SYSTEM, 'r') as f:
         data = json.load(f)
    return data
"""
def get_zone_data(zone):
    global ZONES
    with open(DATA_JSON_FILE_ZONES, 'r') as f:
        data = json.load(f)
        return data[zone]

def set_zone_state(zone, state):
    global ZONES
    with open(DATA_JSON_FILE_ZONES, 'r') as f:
        data = json.load(f)
        data[var] = val
    with open(DATA_JSON_FILE_ZONES, 'w') as f:
        json.dump(data, f)
"""
def set_system_state(action):
    with open(DATA_JSON_FILE_SYSTEM, 'r') as f:
        data = json.load(f)
        if action == 'ON':
            data[str(PIN_READ_STATE)]['gpio'] = 1
            data[str(PIN_READ_STATE)]['status'] = 'ON'
        elif action == 'OFF':
            data[str(PIN_READ_STATE)]['gpio'] = 0
            data[str(PIN_READ_STATE)]['status'] = 'OFF'
    with open(DATA_JSON_FILE_SYSTEM, 'w') as f:
        json.dump(data, f)
