import json, os.path

#FSM_STATE = ['UNDEFINED', 'ON', 'OFF', 'ALARM']
#ZONE_STATE = ['UNDEFINED', 'OFF', 'DETECTING', 'DETECTED', 'ACK']

DATA_JSON_FILE = 'data.json'

def init_data():
    if not os.path.isfile(DATA_JSON_FILE):
        data = {
           'state_fsm' : 'UNDEFINED',
           'state_zone1' : 'UNDEFINED',
           'state_zone2' : 'UNDEFINED',
        }
        save_data(data)

def print_data():
    with open(DATA_JSON_FILE, 'r') as f:
        data = json.load(f)
        print(data)

def save_data(data):
    with open(DATA_JSON_FILE, 'w') as f:
        json.dump(data, f)

def get_data(var):
    with open(DATA_JSON_FILE, 'r') as f:
        data = json.load(f)
        return data[var]

def set_data(var, val):
    with open(DATA_JSON_FILE, 'r') as f:
        data = json.load(f)
        data[var] = val
    with open(DATA_JSON_FILE, 'w') as f:
        json.dump(data, f)


def tuto():
    data['state_fsm'] = 'titi'
    
    # PYTHON data structure -> JSON
    json_str = json.dumps(data, indent=4)
    # JSON -> PYTHON data structure
    data = json.loads(json_str)

    # Writing JSON data
    with open('data.json', 'w') as f:
        json.dump(data, f)

    # Reading data back
    with open('data.json', 'r') as f:
        data = json.load(f)


#print(init_data())
#set_data('state_fsm', 'RRRROOOOORRRRr')
#print_data()
#print(get_data('state_fsm'))
