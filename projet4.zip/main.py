#PROJET 4

#import RPi.GPIO as GPIO
from flask import *
from mydata import *
app = Flask(__name__)

#GPIO.setmode(GPIO.BCM)

# Create a dictionary called pins to store the pin number, name, and pin state:
ZONES = {
   23 : {'name' : 'zone 1', 'state' : 0},
   24 : {'name' : 'zone 2', 'state' : 0},
   25 : {'name' : 'zone 3', 'state' : 0},
   26 : {'name' : 'zone 4', 'state' : 0}
   }

SYSTEM_STATE = 1

# Set each pin as an output and make it low:
#for pin in pins:
#   GPIO.setup(pin, GPIO.OUT)
#   GPIO.output(pin, GPIO.LOW)

@app.route("/")
@app.route("/index")
def main():
   global ZONES
   # For each pin, read the pin state and store it in the pins dictionary:
   for pin in ZONES:
      ZONES[pin]['state'] = 1
   # Put the pin dictionary into the template data dictionary:
   templateData = {
      'pins' : ZONES,
      'system_state' : get_data('state_fsm')
   }
   # Pass the template data into the template main.html and return it to the user
   return render_template('index.html', **templateData)


@app.route('/SetSystem', methods=['POST'])
def SetSystem():
    global SYSTEM_STATE
    global ZONES
    action =  request.form['btnAction'];
    set_data('state_fsm', action)
    return json.dumps({'status':'OK','system_state':get_data('state_fsm')});


# The function below is executed when someone requests a URL with the pin number and action in it:
@app.route("/<changePin>/<action>")
def action(changePin, action):
   global ZONES
   # Convert the pin from the URL into an integer:
   changePin = int(changePin)
   # Get the device name for the pin being changed:
   deviceName = ZONES[changePin]['name']
   # If the action part of the URL is "on," execute the code indented below:
   if action == "on":
      # Set the pin high:
      ZONES[changePin]['state'] = 1
      # Save the status message to be passed into the template:
      message = "Turned " + deviceName + " on."
   if action == "off":
      ZONES[changePin]['state'] = 0
      message = "Turned " + deviceName + " off."

   # For each pin, read the pin state and store it in the pins dictionary:
   #for pin in pins:
   #   pins[pin]['state'] = 0

   # Along with the pin dictionary, put the message into the template data dictionary:
   templateData = {
      'pins' : ZONES,
      'system_state' : SYSTEM_STATE
   }
   return render_template('index.html', **templateData)

@app.route("/system_state/<action>", methods=['POST', 'GET'])
def system_state(action):
   global SYSTEM_STATE
   if action == "on":
      SYSTEM_STATE = 1
   if action == "off":
      SYSTEM_STATE = 0
   templateData = {
      'pins' : ZONES,
      'system_state' : SYSTEM_STATE
   }
   #return render_template('index.html', **templateData)
   return redirect(url_for('main'))

if __name__ == "__main__":
   app.run(host="0.0.0.0", debug=True)
